#distribpy
Package to implement distribution functions
* Binomial
* Normal