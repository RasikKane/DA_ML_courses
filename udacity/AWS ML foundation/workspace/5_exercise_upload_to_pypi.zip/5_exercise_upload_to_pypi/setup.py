from setuptools import setup

setup(name='distribpy',
      version='0.2',
      description='Gaussian distributions',
      packages=['distribpy'],
      author = 'Rasik Kane',
      author_email = 'rasik.kane@gmail.com',
      zip_safe=False)
